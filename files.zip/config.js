/**
 * CONFIG.JS
 * Static, unchanging data: game phases, all tunable numbers, tile type enum.
 * Nothing in this file reads or writes game state — pure constants only.
 */

// =============================================================================
// GAME PHASE
// =============================================================================

export const GamePhase = {
  PLACEMENT: "placement",
  COMBAT: "combat",
};

// =============================================================================
// CONFIGURATION
// =============================================================================

export const CONFIG = {
  TILE_SIZE: 64,
  MAP_COLS: 50,
  MAP_ROWS: 38,

  CAMERA_SPEED: 400,
  ZOOM_MIN: 0.4,
  ZOOM_MAX: 2.5,
  ZOOM_STEP: 0.1,

  BG_IMAGE_URL:
    "https://placehold.co/3200x2432/3a5a40/8fbc8f?text=Tower+Defense+Map",

  TILE_COLORS: {
    walkable: "rgba(80, 200, 120, 0.30)",
    blocked: "rgba(200, 70, 70, 0.50)",
  },

  // --- Phase 3 & 6: enemies ---
  ENEMY_TYPES: {
    basic: {
      id: "basic",
      monsterValue: 10,
      hp: 100,
      speed: 140,
      xpReward: 3,
      fortDamage: 5,
      color: "#e74c3c",
    },
    scout: {
      id: "scout",
      monsterValue: 8,
      hp: 60,
      speed: 220,
      xpReward: 3,
      fortDamage: 3,
      color: "#f1c40f",
    },
    tough: {
      id: "tough",
      monsterValue: 25,
      hp: 200,
      speed: 110,
      xpReward: 12,
      fortDamage: 10,
      color: "#8e44ad",
    },
    elite: {
      id: "elite",
      monsterValue: 60,
      hp: 450,
      speed: 85,
      xpReward: 30,
      fortDamage: 25,
      color: "#2ecc71",
    },
  },

  /**
 * Wave definitions — each wave has a Monster Value budget, a spawn `period`
 * (total seconds the wave's enemies spawn across), and how many spawn
 * points to cycle through (`activeSpawnPoints`).
 *
 * Groups: { type, count, packSize? } — enemies spread evenly across the
 * wave's period. `packSize` spawns that many enemies together per "pack"
 * (e.g. count 9, packSize 3 → 3 packs of 3, spaced evenly across period).
 * All groups in a wave interleave (mix together) rather than playing one
 * group after another. Escape hatch: a group can set `interval` instead,
 * for a fixed spawn gap that ignores the wave's period.
 *
 * Monster Value = sum of (enemy.monsterValue × count) per group.
 * Values: basic (10), scout (8), tough (25), elite (60)
 */
  WAVES: [
  {
    number: 1,
    monsterValue: 30, // 3 * 10
    period: 3,
    activeSpawnPoints: 1,
    groups: [
      { type: "basic", count: 3 },
    ],
  },
  {
    number: 2,
    monsterValue: 64, // (4 * 10) + (3 * 8)
    period: 4,
    activeSpawnPoints: 1,
    groups: [
      { type: "basic", count: 4 },
      { type: "scout", count: 3, packSize: 3 },
    ],
  },
  {
    number: 3,
    monsterValue: 110, // (7 * 10) + (5 * 8)
    period: 5,
    activeSpawnPoints: 2,
    groups: [
      { type: "basic", count: 7 },
      { type: "scout", count: 5, packSize: 3 },
    ],
  },
  {
    number: 4,
    monsterValue: 160, // (8 * 10) + (10 * 8)
    period: 6,
    activeSpawnPoints: 2,
    groups: [
      { type: "basic", count: 8 },
      { type: "scout", count: 10, packSize: 3 },
    ],
  },
  {
    number: 5,
    monsterValue: 220, // (7 * 10) + (5 * 8) + (4 * 25)
    period: 7,
    activeSpawnPoints: 3,
    groups: [
      { type: "basic", count: 7 },
      { type: "scout", count: 5, packSize: 3 },
      { type: "tough", count: 4 },
    ],
  },
  {
    number: 6,
    monsterValue: 290, // (9 * 10) + (10 * 8) + (4 * 25)
    period: 8,
    activeSpawnPoints: 3,
    groups: [
      { type: "basic", count: 9 },
      { type: "scout", count: 10, packSize: 3 },
      { type: "tough", count: 4 },
    ],
  },
  {
    number: 7,
    monsterValue: 370, // (12 * 10) + (10 * 8) + (7 * 25)
    period: 9,
    activeSpawnPoints: 3,
    groups: [
      { type: "basic", count: 12 },
      { type: "scout", count: 10, packSize: 3 },
      { type: "tough", count: 7 },
    ],
  },
  {
    number: 8,
    monsterValue: 460, // (10 * 10) + (10 * 8) + (4 * 25) + (3 * 60)
    period: 10,
    activeSpawnPoints: 3,
    groups: [
      { type: "basic", count: 10 },
      { type: "scout", count: 10, packSize: 3 },
      { type: "tough", count: 4 },
      { type: "elite", count: 3 },
    ],
  },
  {
    number: 9,
    monsterValue: 560, // (12 * 10) + (15 * 8) + (6 * 25) + (3 * 60)
    period: 11,
    activeSpawnPoints: 3,
    groups: [
      { type: "basic", count: 12 },
      { type: "scout", count: 15, packSize: 3 },
      { type: "tough", count: 6 },
      { type: "elite", count: 3 },
    ],
  },
  {
    number: 10,
    monsterValue: 680, // (15 * 10) + (20 * 8) + (8 * 25) + (3 * 60)
    period: 12,
    activeSpawnPoints: 3,
    groups: [
      { type: "basic", count: 15 },
      { type: "scout", count: 20, packSize: 3 },
      { type: "tough", count: 8 },
      { type: "elite", count: 3 },
      ],
    },
  ],

  MAX_SPAWN_POINTS: 5,
  SPAWN_POINTS: [
    { col: 2, row: 10 },
    { col: 2, row: 12 },
    { col: 2, row: 11 },
    null,
    null,
  ],
  FORT: { col: 46, row: 19 },
  // --- Fort HP system ---
  FORT_MAX_HP: 30,
  FORT_WAVE_REGEN: 5,
  MARKER_COLORS: {
    spawn: "#9b59b6",
    fort: "#f1c40f",
    enemy: ["#e74c3c", "#3498db", "#e67e22", "#1abc9c", "#e91e63"],
  },

  // --- Phase 4, 5 & 7: towers (unlocked via Skill Tree) ---
  STARTING_XP: 30,

  /** Starting skill nodes — each unlocks a tower type */
  SKILL_TREE: [
    { id: "slayer", label: "Slayer", towerType: "slayer", cost: 10 },
    { id: "spearman", label: "Spearman", towerType: "spearman", cost: 10 },
    { id: "striker", label: "Striker", towerType: "striker", cost: 10 },
    { id: "marksman", label: "Marksman", towerType: "marksman", cost: 10 },
  ],

  TOWER_TYPES: {
    // Melee, cone-shaped attack in front of the tower. Wide angle, short-mid range.
    slayer: {
      id: "slayer",
      label: "Slayer",
      maxCount: 1, // base cap; skill tree can raise this later
      radius: 28,
      range: 200,
      damage: 50,
      attackSpeed: 0.5,
      attackType: "cone",
      coneAngle: (Math.PI * 2) / 3, // 120° wide cone
      color: "#e74c3c",
    },
    // Melee, directional attack — narrow cone but longer range than Slayer.
    spearman: {
      id: "spearman",
      label: "Spearman",
      maxCount: 2, // base cap; skill tree can raise this later
      radius: 28,
      range: 356,
      damage: 16,
      attackSpeed: 1.2,
      attackType: "directional",
      coneAngle: Math.PI / 10, // 30° narrow cone (thrust line)
      color: "#2ecc71",
    },
    // Melee, circular AoE around itself — no direction needed.
    striker: {
      id: "striker",
      label: "Striker",
      maxCount: 1, // base cap; skill tree can raise this later
      radius: 26,
      range: 180,
      damage: 10,
      attackSpeed: 2.0,
      attackType: "aoe",
      color: "#e67e22",
    },
    // Ranged — targets the enemy closest to the Fort (not closest to itself).
    marksman: {
      id: "marksman",
      label: "Marksman",
      maxCount: 2, // base cap; skill tree can raise this later
      radius: 26,
      range: 450,
      damage: 23,
      attackSpeed: 1.0,
      attackType: "targeted",
      projectileSpeed: 850,
      projectileColor: "#3498db",
      color: "#3498db",
    },
  },
};

CONFIG.MAP_WIDTH = CONFIG.MAP_COLS * CONFIG.TILE_SIZE;
CONFIG.MAP_HEIGHT = CONFIG.MAP_ROWS * CONFIG.TILE_SIZE;

// =============================================================================
// TALENT TREE TUNING — every number that shapes how talent trees play.
// Change values here; nothing else needs touching for a pure numbers tweak.
// =============================================================================

// Default XP cost per point, for any node that doesn't set its own `cost`/`costs`.
CONFIG.TALENT_POINT_COST = 10;

// A tier unlocks the next one once TOTAL points spent in it (across all its
// nodes) reaches this. Applies uniformly to every tier→next-tier gate.
CONFIG.TALENT_TIER_UNLOCK_THRESHOLD = 5;

// Root gate (tier 0) is a special case — just needs this many points spent
// (out of its 3) to open tier 1.
CONFIG.TALENT_ROOT_UNLOCK_THRESHOLD = 1;

// Crit damage before any "Crit Damage" talent points are spent (150%).
CONFIG.BASE_CRIT_DAMAGE_MULTIPLIER = 1.5;

// Safety floors so stacked talents can't break the math (near-0 attack
// interval, near-0 bleed duration).
CONFIG.MIN_ATTACK_INTERVAL = 0.05;
CONFIG.MIN_BLEED_DURATION = 1;

/**
 * --- Talent trees (per-tower deeper progression, spent from the same XP pool) ---
 *
 * Node shape:
 *   id, label, maxPoints
 *   cost: <number>            — flat XP per point (default: CONFIG.TALENT_POINT_COST)
 *   costs: [<number>, ...]    — OR an escalating cost per point (costs[0] = 1st point, etc.)
 *   requires: { nodeId, min } — OPTIONAL single-parent prerequisite: this many
 *                               points must be in that node (usually from the
 *                               tier above) before this node can be spent into.
 *   exclusiveGroup: "name"    — OPTIONAL: only one node sharing this tag (tree-wide)
 *                               can ever have points — picking one locks the rest.
 *   effect: { type, ... }     — OPTIONAL: how this node changes combat stats.
 *                               No `effect` = spendable but currently a no-op
 *                               (used for reserved/stub nodes). See
 *                               talent-effects.js for the full list of types.
 *
 * A tier unlocks once the PREVIOUS tier's own `unlock` rule is met (checked
 * against that tier's total points spent). Nodes within an unlocked tier are
 * further gated individually by their own `requires`/`exclusiveGroup`, if set.
 */
CONFIG.TALENT_TREES = {
  slayer: {
    tiers: [
      {
        id: "root",
        unlock: { type: "sum", threshold: CONFIG.TALENT_ROOT_UNLOCK_THRESHOLD },
        nodes: [
          {
            id: "root",
            label: "Slayer",
            maxPoints: 3,
            costs: [10, 20, 100],
            unlocksTower: true, // spending the first point IS the tower unlock — no separate purchase
            desc: "Commit to the Slayer's talent path. First point unlocks the tower.",
          },
        ],
      },
      {
        id: "tier1",
        unlock: { type: "sum", threshold: CONFIG.TALENT_TIER_UNLOCK_THRESHOLD },
        nodes: [
          {
            id: "dmg1",
            label: "Damage",
            maxPoints: 5,
            cost: 10,
            effect: { type: "flatDamage", perPoint: 1 },
            desc: "+1 damage per point.",
          },
          {
            id: "aoe",
            label: "Area of Effect",
            maxPoints: 3,
            cost: 10,
            effect: { type: "flatRange", perPoint: 20 },
            desc: "+20 attack range per point.",
          },
          {
            id: "atkspd",
            label: "Attack Speed",
            maxPoints: 2,
            cost: 10,
            // ASSUMPTION: the spec listed 3 reduction values (-0.3/-0.2/-0.1) but
            // capped this node at 2 points — using the first two. Add a third
            // entry (and bump maxPoints to 3) if a 3rd level was intended.
            effect: { type: "attackInterval", perLevelReduction: [0.3, 0.2] },
            desc: "-0.3s / -0.2s attack interval per level.",
          },
        ],
      },
      {
        id: "tier2",
        unlock: { type: "sum", threshold: CONFIG.TALENT_TIER_UNLOCK_THRESHOLD },
        nodes: [
          {
            id: "bleed",
            label: "Bleeding",
            maxPoints: 3,
            costs: [20, 30, 40],
            exclusiveGroup: "special",
            // ASSUMPTION: spec gave +30%/+20%/+20% (totals 30/50/70% over 3/4/5s)
            // but then asked for max level to land on 100%/5s so DPS keeps
            // climbing each level instead of flattening. Implemented as total
            // (not incremental) % per level: 30% (10%/s) -> 50% (12.5%/s) ->
            // 100% (20%/s). Tune the `percent` values below directly.
            effect: {
              type: "bleed",
              levels: [
                { percent: 30, duration: 3 },
                { percent: 50, duration: 4 },
                { percent: 100, duration: 5 },
              ],
            },
            desc: "On-hit bleed: 30% / 50% / 100% of hit damage over 3s / 4s / 5s.",
          },
          {
            id: "raoe",
            label: "Radial AoE",
            maxPoints: 3,
            // ASSUMPTION: cost not specified — mirrored Bleeding's cost since
            // they're the two exclusive picks in this tier.
            costs: [20, 30, 40],
            exclusiveGroup: "special",
            // Widens Slayer's cone toward a full 360°, 1/3 of the remaining
            // angle per point — computed from the base cone so it always
            // reaches exactly 360° at max, even if the base cone changes.
            effect: {
              type: "coneAngle",
              perPoint: (Math.PI * 2 - CONFIG.TOWER_TYPES.slayer.coneAngle) / 3,
            },
            desc: "Widens the attack cone toward a full 360° circle.",
          },
          {
            id: "dmg2",
            label: "Damage",
            maxPoints: 5,
            cost: 10,
            effect: { type: "flatDamage", perPoint: 1 },
            desc: "+1 damage per point.",
          },
        ],
      },
      {
        id: "tier3",
        unlock: { type: "sum", threshold: CONFIG.TALENT_TIER_UNLOCK_THRESHOLD },
        nodes: [
          {
            id: "deepwounds",
            label: "Deep Wounds",
            maxPoints: 2,
            cost: 20,
            requires: { nodeId: "bleed", min: 1 },
            effect: { type: "bleedDurationReduction", perPoint: 1 },
            desc: "-1s total bleed duration per point (same total damage).",
          },
          {
            id: "raoe_range",
            label: "Radial Range",
            maxPoints: 2,
            cost: 20,
            requires: { nodeId: "raoe", min: 1 },
            effect: { type: "flatRange", perPoint: 30 },
            desc: "+30 attack range per point.",
          },
          {
            id: "dmg3",
            label: "Damage",
            maxPoints: 5,
            cost: 10,
            effect: { type: "flatDamage", perPoint: 1 },
            desc: "+1 damage per point.",
          },
        ],
      },
      {
        id: "tier4",
        unlock: { type: "sum", threshold: CONFIG.TALENT_TIER_UNLOCK_THRESHOLD },
        nodes: [
          {
            id: "critchance",
            label: "Crit Chance",
            maxPoints: 5,
            cost: 20,
            effect: { type: "critChance", perLevel: [15, 10, 5, 5, 5] },
            desc: "+15/+10/+5/+5/+5% crit chance per level. Crits deal 150% damage (base).",
          },
          {
            id: "bleed_plus",
            label: "Bleeding+",
            maxPoints: 1,
            // TBD: reserved slot, no effect defined yet — placeholder cost.
            cost: 10,
            requires: { nodeId: "bleed", min: 1 },
            desc: "Reserved — effect not designed yet.",
          },
          {
            id: "raoe_plus",
            label: "Radial AoE+",
            maxPoints: 1,
            // TBD: reserved slot, no effect defined yet — placeholder cost.
            cost: 10,
            requires: { nodeId: "raoe", min: 1 },
            desc: "Reserved — effect not designed yet.",
          },
        ],
      },
      {
        id: "tier5",
        unlock: null, // last tier
        nodes: [
          {
            id: "critdamage",
            label: "Crit Damage",
            maxPoints: 2,
            cost: 30,
            requires: { nodeId: "critchance", min: 1 },
            effect: { type: "critDamage", perLevel: [30, 20] },
            desc: "+30% / +20% crit damage per level (on top of the 150% base).",
          },
        ],
      },
    ],
  },
  // spearman / striker / marksman talent trees not designed yet
};

// --- Main Menu: map select ---
// designWaveCount is the spec target (10/map); actual playable wave count
// right now is CONFIG.WAVES.length (only Map 1 has real wave data so far).
CONFIG.MAPS = [
  { id: "map1", label: "Map 1", designWaveCount: 10, requiresMapId: null },
  { id: "map2", label: "Map 2", designWaveCount: 10, requiresMapId: "map1" },
  { id: "map3", label: "Map 3", designWaveCount: 10, requiresMapId: "map2" },
];

// --- Main Menu: difficulty select (UI only for now — not yet applied to gameplay) ---
CONFIG.DIFFICULTIES = [
  { id: "normal", label: "Normal" },
  { id: "hard", label: "Hard" },
  { id: "veryhard", label: "Very Hard" },
];

// =============================================================================
// TILE TYPES
// =============================================================================

export const TILE = {
  WALKABLE: 0,
  BLOCKED: 1,
};
